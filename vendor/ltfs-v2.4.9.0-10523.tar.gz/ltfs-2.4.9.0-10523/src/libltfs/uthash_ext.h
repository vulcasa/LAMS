/*
**
**  OO_Copyright_BEGIN
**
**
**  Copyright 2010, 2025 IBM Corp. All rights reserved.
**
**  Redistribution and use in source and binary forms, with or without
**   modification, are permitted provided that the following conditions
**  are met:
**  1. Redistributions of source code must retain the above copyright
**     notice, this list of conditions and the following disclaimer.
**  2. Redistributions in binary form must reproduce the above copyright
**     notice, this list of conditions and the following disclaimer in the
**  documentation and/or other materials provided with the distribution.
**  3. Neither the name of the copyright holder nor the names of its
**     contributors may be used to endorse or promote products derived from
**     this software without specific prior written permission.
**
**  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS ``AS IS''
**  AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
**  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
**  ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
**  LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
**  CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
**  SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
**  INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
**  CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
**  ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
**  POSSIBILITY OF SUCH DAMAGE.
**
**
**  OO_Copyright_END
*/

/*************************************************************************************
 ** FILE NAME:       uthash_ext.h
 **
 ** DESCRIPTION:     Header file for HASH function extensions.
 **
 ** AUTHORS:
 **                  IBM Yamato, Japan
 **
 *************************************************************************************
 */
#ifndef __uthash_ext_h
#define __uthash_ext_h

#ifdef __cplusplus
extern "C" {
#endif

/* Define OOM handling macros before including uthash */
#undef HASH_NONFATAL_OOM
#define HASH_NONFATAL_OOM 1

#undef uthash_nonfatal_oom
#define uthash_nonfatal_oom(obj) do { (void)(obj); errno = ENOMEM; } while (0)

#define HASH_FIND_PARTIAL(structure,start,length,table,search,result)	\
do {																	\
	structure *s, *tmp;													\
	result = NULL;														\
	HASH_ITER(hh, table, s, tmp) {										\
		if (HASH_KEYCMP(&s->start, &search.start, length) == 0) {		\
			result = s;													\
			break;														\
		}																\
	}																	\
} while (0)

#ifdef __cplusplus
}
#endif

#endif /* uthash_ext_h */
